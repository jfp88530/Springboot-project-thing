
(function () {
    'use strict';

    angular
        .module('app')
        .controller('BookingsController', BookingsController);

    BookingsController.$inject = ['$http'];

    function BookingsController($http) {
        var vm = this;

        vm.bookings=[];
        vm.getAll=getAll;
        vm.getBank1=getBank1;
        vm.getBank2=getBank2;
        vm.getBank3=getBank3;
        vm.deleteBooking=deleteBooking;
        init();

        function init(){
            getAll();
        }
        
        function getAll() {
            var url="/appointment/all";
            var bookingsPromise = $http.get(url);
            bookingsPromise.then(function (response) {
                vm.bookings=response.data;
            });
        }
        
        function deleteBooking(id) {

            var url="/appointment/delete/"+id+"";
            $http.get(url).then(function(response){
                vm.bookings=response.data;
            });
        }
        function getBank1(){
            var url = "/appointment/location/Bankname1";
            var bookingsPromise = $http.get(url);
            bookingsPromise.then(function(response){
                vm.bookings = response.data;
            });
        }
        function getBank2(){
            var url = "/appointment/location/Bankname2";
            var bookingsPromise = $http.get(url);
            bookingsPromise.then(function(response){
                vm.bookings = response.data;
            });
        }
        function getBank3(){
            var url = "/appointment/location/Bankname3";
            var bookingsPromise = $http.get(url);
            bookingsPromise.then(function(response){
                vm.bookings = response.data;
            });
        }
    }
})();