//package com.ams.amsdemo;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//import java.util.ArrayList;
//import java.util.List;
//
//
//@Component
//public class DBSeeder implements CommandLineRunner {
//    private AppointmentRepo appointmentRepo;
//
//    @Autowired
//    public DBSeeder(AppointmentRepo appointmentRepo){
//        this.appointmentRepo=appointmentRepo;
//    }
//
//    @Override
//    public void run(String... args) throws Exception {
//
//        List<AppointmentBooking> bookings = new ArrayList<>();
//        bookings.add(new AppointmentBooking("Bankname1","Jim j.","jim@com.com","123-456-789","2-25-1889", "Checking", "9:00 am"));
//        bookings.add(new AppointmentBooking("Bankname2","John j.","John@com.com","123-456-789","2-25-1887", "Checking", "8:00 am"));
//        bookings.add(new AppointmentBooking("Bankname3","Joe j.","Joe@com.com","123-456-789","2-25-1887", "Checking", "7:00 am"));
//        bookings.add(new AppointmentBooking("Bankname2","Jeb j.","Jeb@com.com","123-456-789","2-25-1887", "Checking", "6:00 am"));
//
//
//        appointmentRepo.saveAll(bookings);
//
//
//
//    }
//}
