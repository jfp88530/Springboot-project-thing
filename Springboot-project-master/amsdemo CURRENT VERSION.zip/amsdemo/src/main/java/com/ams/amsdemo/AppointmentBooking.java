package com.ams.amsdemo;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AppointmentBooking {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    private String bankName;
    private String email;
    private String phoneNumber;
    private String userName;
    private String service;
    private String date;
    private String time;

    public AppointmentBooking()
    {

    };

    public AppointmentBooking(String bankName, String userName, String email, String phoneNumber, String date, String service, String time){

        this.bankName = bankName;
        this.email=email;
        this.phoneNumber=phoneNumber;
        this.userName = userName;
        this.service = service;
        this.date = date;
        this.time = time;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public Long getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUserName() { return userName; }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public String getTime()
    {
        return time;
    }

    public void setTime(String time)
    {
        this.time = time;
    }

    public String getBankName()
    {
        return bankName;
    }

    public void setBankName(String bankName)
    {
        this.bankName = bankName;
    }

    public String getService() {return service;}

    public void setService(String service) {this.service = service;}


    //public Long getId()
    //{
    //    return id;
    // }
}
