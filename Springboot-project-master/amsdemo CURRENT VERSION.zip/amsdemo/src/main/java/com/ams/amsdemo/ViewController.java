package com.ams.amsdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ViewController {

    private AppointmentRepo appointmentRepo;

    @Autowired
    public ViewController(AppointmentRepo appointmentRepo){
        this.appointmentRepo=appointmentRepo;
    }

    @RequestMapping(value = "/form", method = RequestMethod.GET)
    public String form(){
        return "form";
    }

    @RequestMapping(value = "/booking")
    public String Bookings(){
        return "booking";

    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public String create(String bankName, String userName, String email, String phoneNumber, String date, String service, String time){
        AppointmentBooking appointmentBooking = new AppointmentBooking(bankName, userName,email,phoneNumber, date, service, time);

        appointmentRepo.save(appointmentBooking);
        return "Confirmation";
    }

}
