package com.ams.amsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmsdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AmsdemoApplication.class, args);
    }

}
