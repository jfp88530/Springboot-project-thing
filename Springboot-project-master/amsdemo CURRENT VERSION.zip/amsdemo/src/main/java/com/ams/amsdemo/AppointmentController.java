package com.ams.amsdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = "/appointment")
public class AppointmentController {

    private AppointmentRepo appointmentRepo;

    @Autowired
    public AppointmentController(AppointmentRepo appointmentRepo){
        this.appointmentRepo=appointmentRepo;
    }
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    public List<AppointmentBooking> getAll(){
        return appointmentRepo.findAll();
    }


    @RequestMapping(value = "/location/{bankName}", method = RequestMethod.GET)
    public List<AppointmentBooking> getLocation (@PathVariable String bankName){
        return appointmentRepo.findAll().stream().filter(x ->x.getBankName().equals(bankName)).collect(Collectors.toList());
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public String create(String bankName, String userName, String email, String phoneNumber, String date, String service, String time){
        AppointmentBooking appointmentBooking = new AppointmentBooking(bankName, userName,email,phoneNumber, date, service, time);
        appointmentRepo.save(appointmentBooking);
        return "ffff"; //This literally returns the work "form"
    }

    @RequestMapping(value = "/delete/{id}",method = RequestMethod.GET)
    public List<AppointmentBooking> remove (@PathVariable long id){

        appointmentRepo.deleteById(id);
        return appointmentRepo.findAll();
    }





}
