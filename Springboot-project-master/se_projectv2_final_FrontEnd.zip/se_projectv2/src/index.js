import React from "react";
import ReactDOM from "react-dom";
import * as serviceWorker from "./serviceWorker";
import "bootstrap/dist/css/bootstrap.css";
import Main from "./Main";
import "./Main.css";
import DateTime from "./dateTime";

ReactDOM.render(<Main />, document.getElementById("root"));
serviceWorker.unregister();
