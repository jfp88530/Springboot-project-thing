import React, { Component } from "react";
import checkbook from "./icons/checkbook.svg";
import coins from "./icons/coins-money-stack.svg";
import creditcard from "./icons/credit-cards-payment.svg";
import document from "./icons/document.svg";
import graduate from "./icons/graduate.svg";
import home from "./icons/home.svg";
import mortarboard from "./icons/mortarboard.svg";
import piggy from "./icons/piggy-bank.svg";
import profits from "./icons/profits.svg";
import retirement from "./icons/retirement.svg";
import transaction from "./icons/transaction.svg";
import arrow from "./icons/right-arrow.svg";
import "./apptType.css";
import { Route, NavLink, HashRouter } from "react-router-dom";

class Appointments extends Component {
  state = {};

  render() {
    return (
      <div name="service">
        <h1>Choose your appointment:</h1>
        <button className="btn btn-success m-2 main" value="check">
          <img src="icons/checkbook.svg" className="imgs" />
          <br />
          Checking Account
        </button>
        <button className="btn btn-success m-2 main" value="save">
          <img src={piggy} className="imgs" alt="savings" />
          <br />
          Savings Account
        </button>
        <button className="btn btn-success m-2 main" value="cc">
          <img src={creditcard} className="imgs" alt="credit card" />
          <br />
          Credit Card
        </button>
        <br />
        <button className="btn btn-success m-2 sec" value="home">
          <img src={transaction} className="imgs" alt="home loan" />
          <br />
          Home Loan
        </button>
        <button className="btn btn-success m-2 sec" value="auto">
          <img src={document} className="imgs" alt="auto loan" />
          <br />
          Auto Loan
        </button>
        <button className="btn btn-success m-2 sec" value="studLoan">
          <img src={graduate} className="imgs" alt="student loan" />
          <br />
          Student Loan
        </button>
        <button className="btn btn-success m-2 sec" value="studBank">
          <img src={mortarboard} className="imgs" alt="student banking" />
          <br />
          Student Banking
        </button>
        <br />
        <button className="btn btn-success m-2 sec" value="homeEq">
          <img src={home} className="imgs" alt="home equity" />
          <br />
          Home Equity
        </button>
        <button className="btn btn-success m-2 sec" value="invest">
          <img src={profits} className="imgs" alt="investments" />
          <br />
          Investments
        </button>
        <button className="btn btn-success m-2 sec" value="retire">
          <img src={retirement} className="imgs" alt="retirement" />
          <br />
          Retirement
        </button>
        <button className="btn btn-success m-2 sec" value="mm">
          <img src={coins} className="imgs" alt="money market" />
          <br />
          Money Market
        </button>
        <br />
        <HashRouter>
          <div value="directBtns">
            <NavLink to="/map">
              <button className="btn m-2 nextBtn">
                <img src={arrow} alt="dateSelect" />
              </button>
            </NavLink>
          </div>
        </HashRouter>
      </div>
    );
  }
}

export default Appointments;
