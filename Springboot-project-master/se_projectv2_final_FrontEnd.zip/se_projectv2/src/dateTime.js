import React, { Component } from "react";
import "react-datepicker/dist/react-datepicker.css";
import "./apptType.css";
import { Route, NavLink, HashRouter } from "react-router-dom";
import back from "./icons/back.svg";

class dateTime extends Component {
  render() {
    return (
      <div>
        <div>
          <h1>When would you like your appointment?</h1>
          <br />
          <label>Date: </label>
          <input type="date" min="2019-04-16" label="Date:" />
        </div>
        <br />
        <button className="btn btn-success m-2 times">9:00 AM</button>
        <button className="btn btn-success m-2 times">10:00 AM</button>
        <button className="btn btn-success m-2 times">11:00 AM</button>
        <br />
        <button className="btn btn-success m-2 times">12:00 PM</button>
        <button className="btn btn-success m-2 times">1:00 PM</button>
        <button className="btn btn-success m-2 times">2:00 PM</button>
        <br />
        <button className="btn btn-success m-2 times">3:00 PM</button>
        <button className="btn btn-success m-2 times">4:00 PM</button>
        <button className="btn btn-success m-2 times">5:00 PM</button>
        <div id="directBtns">
          <HashRouter>
            <NavLink to="/map">
              <button className="btn m-2 backBtn">
                <img src={back} />
              </button>
            </NavLink>
          </HashRouter>
        </div>
      </div>
    );
  }
}

export default dateTime;
