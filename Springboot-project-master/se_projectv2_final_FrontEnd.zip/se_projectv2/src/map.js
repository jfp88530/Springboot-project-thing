import React, { Component } from "react";
import { Map, GoogleApiWrapper, InfoWindow, Marker } from "google-maps-react";
import { Route, NavLink, HashRouter } from "react-router-dom";
import "./map.css";
import arrow from "./icons/right-arrow.svg";
import back from "./icons/back.svg";

const mapStyles = {
  margin: "10px 10px 10px 0%",
  height: "600px",
  width: "650px"
};

export class MapContainer extends Component {
  state = {
    showingInfoWindow: false, //hides or shows the infowindow
    activeMarker: {}, //shows the active marker upon click
    selectedPlace: {} //shows the infowindow to the selected place upon a marker
  };

  onMarkerClick = (props, marker, e) =>
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true
    });

  onClose = props => {
    if (this.state.showingInfoWindow) {
      this.setState({
        showingInfoWindow: false,
        activeMarker: null
      });
    }
  };

  render() {
    return (
      <form>
        <div class="content">
          <div id="header">
            <h1>Choose a location:</h1>
          </div>
          <div id="maps">
            <Map
              google={this.props.google}
              zoom={10}
              style={mapStyles}
              initialCenter={{
                lat: 39.1000339,
                lng: -94.5736872
              }}
            >
              <Marker
                onClick={this.onMarkerClick}
                name={"Commerce Bank: 804 E 12th St, Kansas City, MO 64106"}
                position={{ lat: 39.1000339, lng: -94.5736872 }}
              />

              <InfoWindow
                marker={this.state.activeMarker}
                visible={this.state.showingInfoWindow}
                onClose={this.onClose}
              >
                <div>
                  <h4>{this.state.selectedPlace.name}</h4>
                </div>
              </InfoWindow>

              <Marker
                onClick={this.onMarkerClick}
                name={
                  "Commerce Bank: 9001 State Line Rd, Kansas City, MO 64114"
                }
                position={{ lat: 38.96601, lng: -94.60763 }}
              />

              <InfoWindow
                marker={this.state.activeMarker}
                visible={this.state.showingInfoWindow}
                onClose={this.onClose}
              >
                <div>
                  <h4>{this.state.selectedPlace.name}</h4>
                </div>
              </InfoWindow>

              <Marker
                onClick={this.onMarkerClick}
                name={
                  "Commerce Bank: 6336 Brookside Plaza, Kansas City, MO 64113"
                }
                position={{ lat: 39.01253, lng: -94.59116 }}
              />

              <InfoWindow
                marker={this.state.activeMarker}
                visible={this.state.showingInfoWindow}
                onClose={this.onClose}
              >
                <div>
                  <h4>{this.state.selectedPlace.name}</h4>
                </div>
              </InfoWindow>

              <Marker
                onClick={this.onMarkerClick}
                name={
                  "Commerce Bank: 1001 NW Chipman Rd, Lees Summit, MO 64081"
                }
                position={{ lat: 38.92526, lng: -94.40709 }}
              />

              <InfoWindow
                marker={this.state.activeMarker}
                visible={this.state.showingInfoWindow}
                onClose={this.onClose}
              >
                <div>
                  <h4>{this.state.selectedPlace.name}</h4>
                </div>
              </InfoWindow>
            </Map>
          </div>
          <div id="directBtns">
            <HashRouter>
              <NavLink to="/">
                <button className="btn m-2 backBtn">
                  <img src={back} />
                </button>
              </NavLink>
              <NavLink to="/dateTime">
                <button className="btn m-2 nextBtn">
                  <img src={arrow} />
                </button>
              </NavLink>
            </HashRouter>
          </div>
        </div>
      </form>
    );
  }
}

export default GoogleApiWrapper({
  apiKey: "AIzaSyC-_mUhc5YvQASf9qbp8HSk7Rj4ck6kAvU"
})(MapContainer);
