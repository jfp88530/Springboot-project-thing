import React, { Component } from "react";
import { Route, HashRouter } from "react-router-dom";
import Appointment from "./apptType.js";
import MapContainer from "./map";
import DateTime from "./dateTime";

class Main extends Component {
  state = {};
  render() {
    return (
      <HashRouter>
        <div className="content">
          <Route path="/" exact component={Appointment} />
          <Route path="/map" exact component={MapContainer} />
          <Route path="/dateTime" exact component={DateTime} />
        </div>
      </HashRouter>
    );
  }
}

export default Main;
