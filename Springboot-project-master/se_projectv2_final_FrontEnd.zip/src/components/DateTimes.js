import React from 'react';
import 'react-datepicker/dist/react-datepicker.css';
import './appointments.css';
import { NavLink } from 'react-router-dom';

function DateTimes() {
  const [appointments, setAppointments] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch('http://localhost:8080/appointment/all')
      .then(data => data.json())
      .then(appointments => {
        setAppointments(appointments);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      <div>
        <h1>When would you like your appointment?</h1>
        <br />
        <label>Date: </label>
        <input type="date" min="2019-04-16" />
      </div>

      {makeTimes().map(appointment => (
        <NavLink to={`/form?appt=${appointment.time}`} key={appointment.time}>
          <button className="btn btn-success m-2 times">{appointment.time}</button>
        </NavLink>
      ))}

    </div>
  );
}

function makeTimes() {
  const currentDay = new Date();
  currentDay.setHours(9, 0, 0, 0);
  return Array.from({ length: 7 }, (_, hour) => ({
    time: addHours(currentDay, hour).toLocaleTimeString(),
    date: currentDay.toISOString().split('T')[0],
  }));
}

/**
 * @param {Date} date
 * @param {Number} hours
 * @returns {Date}
 */
export function addHours(date, hours) {
  const result = new Date(date);
  result.setHours(result.getHours() + hours);
  return result;
}

export default DateTimes;
