import React from 'react';
import { NavLink } from 'react-router-dom';
import './form.css';

const Form = () => {
  const [state, setState] = React.useState({
    first: '',
    last: '',
    email: '',
    phone: '',
  });

  const [checkState, setCheckState] = React.useState({
    textAgree: false,
    emailAgree: false,
  });

  /**
   * Updates the the state whenever the user types into the field.
   * Spreads the old state values into the object, then overwrites the key
   * that matches e.target.name with e.target.value
   */
  const onChange = e => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  const toggleCheckbox = e => {
    setCheckState({ ...checkState, [e.target.name]: !e.target.name });
  };

  return (
    <div>
      <form>
        <label>
          First Name
          <input name={'first'} value={state.first} onChange={onChange} required />
        </label>

        <label>
          Last Name
          <input name={'last'} value={state.last} onChange={onChange} required />
        </label>

        <label>
          Email
          <input type={'email'} name={'email'} value={state.email} onChange={onChange} required />
        </label>

        <label>
          Phone
          <input name={'phone'} value={state.phone} onChange={onChange} required />
        </label>

        <label>
          Receive text message updates
          <input
            name={'textAgree'}
            value={checkState.textAgree}
            type={'checkbox'}
            onChange={toggleCheckbox}
          />
        </label>

        <label>
          Receive email updates updates
          <input
            name={'emailAgree'}
            value={checkState.emailAgree}
            type={'checkbox'}
            onChange={toggleCheckbox}
          />
        </label>

        <NavLink to={'/summary'}>
          <button>Submit</button>
        </NavLink>
      </form>
    </div>
  );
};

export default Form;
