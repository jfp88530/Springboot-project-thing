import React from 'react';
import { NavLink } from 'react-router-dom';

import { ReactComponent as coins } from '../icons/coins-money-stack.svg';
import { ReactComponent as checkbook } from '../icons/checkbook.svg';
import { ReactComponent as creditcard } from '../icons/credit-cards-payment.svg';
import { ReactComponent as document } from '../icons/document.svg';
import { ReactComponent as graduate } from '../icons/graduate.svg';
import { ReactComponent as home } from '../icons/home.svg';
import { ReactComponent as mortarboard } from '../icons/mortarboard.svg';
import { ReactComponent as piggy } from '../icons/piggy-bank.svg';
import { ReactComponent as profits } from '../icons/profits.svg';
import { ReactComponent as retirement } from '../icons/retirement.svg';
import { ReactComponent as transaction } from '../icons/transaction.svg';
import { ReactComponent as Arrow } from '../icons/right-arrow.svg';
import './appointments.css';

const services = [
  { name: 'check', label: 'Checking Account', Icon: checkbook },
  { name: 'save', label: 'Savings Account', Icon: piggy },
  { name: 'cc', label: 'Credit Card', Icon: creditcard },
  { name: 'home', label: 'Home Loan', Icon: transaction },
  { name: 'auto', label: 'Auto Loan', Icon: document },
  { name: 'studLoan', label: 'Student Loan', Icon: graduate },
  { name: 'studBank', label: 'Student Banking', Icon: mortarboard },
  { name: 'homeEq', label: 'Home Equity', Icon: home },
  { name: 'invest', label: 'Investments', Icon: profits },
  { name: 'retire', label: 'Retirement', Icon: retirement },
  { name: 'mm', label: 'Money Market', Icon: coins },
];

function Appointments() {
  const [selected, setSelected] = React.useState(null);

  console.log(selected);

  return (
    <div>
      <h1>Choose your appointment:</h1>

      {services.map(({ name, label, Icon }) => (
        <button
          onClick={() => {
            setSelected(name);
          }}
          className={`btn btn-success m-2 main ${selected === name && 'selected'}`}
          value={name}
          key={name}
        >
          <Icon />
          <div>{label}</div>
        </button>
      ))}
      <div>
        <NavLink to={`/map?service=${selected}`}>
          <button className="btn m-2 nextBtn">
            <Arrow />
          </button>
        </NavLink>
      </div>
    </div>
  );
}

export default Appointments;
