import React from 'react';

const Summary = props => {
  const fakeData = {
    branchName: '123 branch st',
    appointmenetDateTime: new Date(),
  };

  const submit = () => {
    fetch('http://localhost:8080/appointment/create', {
      method: 'POST',
      body: JSON.stringify({ fakeData }),
    });
  };

  return (
    <form onSubmit={submit}>
      <div>Stuff</div>

      <button>Submit</button>
    </form>
  );
};

export default Summary;
