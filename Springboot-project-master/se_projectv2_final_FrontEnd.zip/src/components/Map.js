import React from 'react';
import { Map, GoogleApiWrapper, InfoWindow, Marker } from 'google-maps-react';
import { NavLink, Redirect, withRouter } from 'react-router-dom';
import arrow from '../icons/right-arrow.svg';
import './map.css';

const mapStyles = {
  margin: '10px 10px 10px 0%',
  height: '600px',
  width: '650px',
};

function MapComponent(props) {
  const [branches, setBranches] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [selected, setSelected] = React.useState({
    showingInfoWindow: false,
    selectedPlace: {},
  });

  React.useEffect(() => {
    try {
      fetch('http://localhost:8080/appointment/branch')
        .then(data => data.json())
        .then(branches => {
          setBranches(branches);
          setLoading(false);
        });
    } catch (ex) {
      console.log(ex);
      setBranches(mockBranches);
    }
  }, []);

  const onMarkerClick = (props, marker) => {
    setSelected({
      selectedPlace: {
        name: marker.name,
      },
      activeMarker: marker,
      showingInfoWindow: true,
    });
  };

  const onClose = () => {
    if (selected.showingInfoWindow) {
      setSelected({ ...selected, showingInfoWindow: false });
    }
  };

  return loading ? (
    <p>Loading</p>
  ) : (
    <div className="content">
      <div id="header">
        <h1>Choose a location:</h1>
      </div>
      <div id="maps">
        <Map
          google={props.google}
          zoom={10}
          style={mapStyles}
          initialCenter={{
            lat: 39.1000339,
            lng: -94.5736872,
          }}
        >
          {branches.map(branch => (
            <Marker
              key={branch.id}
              onClick={onMarkerClick}
              name={branch.address}
              position={{ lat: branch.lat, lng: branch.lon }}
            />
          ))}

          <InfoWindow
            marker={selected.activeMarker}
            visible={selected.showingInfoWindow}
            onClose={onClose}
          >
            <div>
              <h4>{selected.selectedPlace.name}</h4>
              <button type={'button'}>Select This Branch</button>
            </div>
          </InfoWindow>
        </Map>
      </div>
      <div id={'directBtns'}>
        <NavLink to="/">
          <button className={'btn m-2 backBtn'}>
            <img src={arrow} alt={'arrow'} />
          </button>
        </NavLink>
        <NavLink to="/dateTime">
          <button className="btn m-2 nextBtn">
            <img src={arrow} alt={'arrow'} />
          </button>
        </NavLink>
      </div>
    </div>
  );
}

export default GoogleApiWrapper({
  apiKey: 'AIzaSyC-_mUhc5YvQASf9qbp8HSk7Rj4ck6kAvU',
})(withRouter(MapComponent));

// for development
const mockBranches = [
  {
    id: 1,
    address: 'Commerce Bank: 804 E 12th St, Kansas City, MO 64106',
    lat: 39.1000339,
    lon: -94.5736872,
  },
  {
    id: 2,
    address: 'Commerce Bank: 9001 State Line Rd, Kansas City, MO 64114',
    lat: 38.96601,
    lon: -94.60763,
  },
  {
    id: 3,
    address: 'Commerce Bank: 6336 Brookside Plaza, Kansas City, MO 64113',
    lat: 39.01253,
    lon: -94.59116,
  },
];
