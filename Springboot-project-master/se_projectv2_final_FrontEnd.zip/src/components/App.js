import React from 'react';
import { Route, BrowserRouter, Switch } from 'react-router-dom';
import MapContainer from './Map';
import DateTime from './DateTimes';
import Appointments from './Appointments';
import Form from './Form';
import Summary from './Summary';

function App() {
  return (
    <BrowserRouter>
      <div className="content">
        <Switch>
          <Route path="/map" component={MapContainer} />
          <Route path="/dateTime" component={DateTime} />
          <Route path="/form" component={Form} />
          <Route path="/summary" component={Summary} />
          <Route component={Appointments} />
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
