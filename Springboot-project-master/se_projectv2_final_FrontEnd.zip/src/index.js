import React from 'react';
import ReactDOM from 'react-dom';
import * as serviceWorker from './serviceWorker';
import 'bootstrap/dist/css/bootstrap.css';
import App from './components/App';
import './Main.css';
import './App.css';

ReactDOM.render(<App />, document.getElementById('root'));

serviceWorker.unregister();
